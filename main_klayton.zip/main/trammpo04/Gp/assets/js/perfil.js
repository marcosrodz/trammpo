document.addEventListener("DOMContentLoaded", function(event) { 

   

    const images =  document.querySelectorAll('.mole');
    
    fileInput.addEventListener('change', (e) =>{
        const file = e.target.files[0];
    
        let fileReader = new FileReader();
        fileReader.readAsDataURL(file);
        fileReader.onload = function (){
            images[0].setAttribute('src', fileReader.result);
            // images[0].setAttribute('style', `background-image: url('${fileReader.result}')`);
        }
    })
});

