var app = angular.module("myApp", []);

app.controller('cliente', function($scope){
      
  $scope.mostrarCliente = function()
  {
    $scope.mostra_prestador = false;
    $scope.mostra_cliente = true;
  }

  $scope.mostrarPrestador = function()
  {
    $scope.mostra_cliente = false;
    $scope.mostra_prestador = true;
  }
});