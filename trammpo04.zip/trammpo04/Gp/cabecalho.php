<header id="header" class="fixed-top header-inner-pages">
  <div class="container d-flex align-items-center justify-content-lg-between">

    <h1 class="logo me-auto me-lg-0"><a href="index.php">T<span>.</span></a></h1>
    <!-- Uncomment below if you prefer to use an image logo -->
    <!-- <a href="index.html" class="logo me-auto me-lg-0"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

    <nav id="navbar" class="navbar order-last order-lg-0">
      <ul>
      <li><a class="nav-link scrollto active" href="index.php">Home</a></li>
          <li> <a class="nav-link scrollto" aria-current="page" href="servicos.php">Serviços</a></li>
          <li><a class="nav-link scrollto " aria-current="page" href="listadeprestadores.php">Prestadores</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li><a class="nav-link scrollto" href="index.php#contact">Contato</a></li>
        </li>
          
      <i class="bi bi-list mobile-nav-toggle"></i>
    </nav><!-- .navbar -->

    <a href="cadastro/formLogin.php" class="get-started-btn scrollto">Cadastrar | Conectar</a>
    <a href="http://wa.me/5544984198747" target="_blank"><button type="button" class="btn btn-primary">Primary</button></a>

  </div>
</header><!-- End Header -->